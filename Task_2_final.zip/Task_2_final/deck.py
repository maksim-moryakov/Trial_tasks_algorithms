"""
ID 88971821

Гоша реализовал структуру данных Дек, максимальный размер которого определяется
заданным числом. Методы push_back(x), push_front(x), pop_back(), pop_front()
работали корректно. Но, если в деке было много элементов, программа работала
очень долго. Дело в том, что не все операции выполнялись за O(1).
Помогите Гоше! Напишите эффективную реализацию.
Внимание: при реализации используйте кольцевой буфер.
"""

from typing import Tuple


class Desk:
    def __init__(self, max_size):
        self.buffer = [None] * max_size
        self.start = 0
        self.end = 0
        self.size = 0
        self.max_size = max_size

    def is_empty(self):
        return self.size == 0

    def is_full(self):
        return self.size == self.max_size

    def push_back(self, item):
        if self.is_full():
            return print("error")
        
        self.buffer[self.end] = item
        self.end = (self.end + 1) % self.max_size
        self.size += 1


    def push_front(self, item):
        if self.is_full():
            return print("error")
        self.start = (self.start - 1) % self.max_size
        self.buffer[self.start] = item
        self.size += 1


    def pop_back(self):
        if self.is_empty():
            return print("error")
        self.end = (self.end - 1) % self.max_size
        item = self.buffer[self.end]
        self.size -= 1
        print(item)


    def pop_front(self):
        if self.is_empty():
            return print("error")
        item = self.buffer[self.start]
        self.start = (self.start + 1) % self.max_size
        self.size -= 1
        print(item)


def main() -> Tuple[int, int]:
    n = int(input())
    max_size = int(input())
    deque = Desk(max_size)

    for _ in range(n):
        item = input().split()
        if item[0] == "push_back":
            deque.push_back(int(item[1]))
        elif item[0] == "push_front":
            deque.push_front(int(item[1]))
        elif item[0] == "pop_back":
            deque.pop_back()
        elif item[0] == "pop_front":
            deque.pop_front()


if __name__ == '__main__':
    main()