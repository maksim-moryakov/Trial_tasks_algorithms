"""
ID 89184226

Формат ввода
В первой строке задано число участников n, 1 ≤ n ≤ 100 000.
В каждой из следующих n строк задана информация про одного из участников.
i-й участник описывается тремя параметрами:
- уникальным логином (строкой из маленьких латинских букв длиной не более 20)
- числом решённых задач Pi
- штрафом Fi
Fi и Pi — целые числа, лежащие в диапазоне от 0 до 109.

Формат вывода
Для отсортированного списка участников выведите по порядку их логины по одному в строке.

"""

def quick_sort(arr: list) -> None:
    def partition(arr: list, low: int, high: int) -> int:
        turn = arr[high]
        i = low - 1
        for j in range(low, high):
            if arr[j][1] > turn[1] or \
                (arr[j][1] == turn[1] and arr[j][2] < turn[2]) or \
                      (arr[j][1] == turn[1] and arr[j][2] == turn[2] and 
                       arr[j][0] < turn[0]):
                i += 1
                arr[i], arr[j] = arr[j], arr[i]
        arr[i+1], arr[high] = arr[high], arr[i+1]
        return i+1
    
    def quick_sort_helper(arr: list, low: int, high: int) -> None:
        if low < high:
            pi = partition(arr, low, high)
            quick_sort_helper(arr, low, pi-1)
            quick_sort_helper(arr, pi+1, high)
    
    quick_sort_helper(arr, 0, len(arr)-1)

def main() -> None:
    n = int(input())
    users = []
    for i in range(n):
        login, p, f = input().split()
        users.append((login, int(p), int(f)))

    quick_sort(users)

    for user in users:
        print(user[0])

if __name__ == '__main__':
    main()